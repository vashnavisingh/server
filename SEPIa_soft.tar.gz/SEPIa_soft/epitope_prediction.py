from __future__ import division

"""

SEPIa, a knowledge-driven algorithm for predicting B-cell epitopes from the amino acid sequence

"""


#######################################################

import csv as csv
import pandas as pd
import numpy as np
from sklearn.externals import joblib

#######################################################
#	   Read the csv file with the features	     	  #
#######################################################

MyTestFile = pd.read_csv('/your_path/SEPIa/window/features/features_w9.csv', sep=',')

test_file_object = np.array(MyTestFile)

dataTest=[]
ids = []
for row in test_file_object:
	ids.append(row[0])
	dataTest.append(row[1:])
dataTest = np.array(dataTest)

dataT = np.array(dataTest)

#######################################################
#    	  Convert all strings to integer        	  #
#######################################################

#	Energy-like epitope propensities
#	Epitope (E) or non-Epitope (N)
dataT[dataT[0::,9] =='E',9] = 1
dataT[dataT[0::,9] =='N',9] = 0
dataT[dataT[0::,10] =='E',10] = 1
dataT[dataT[0::,10] =='N',10] = 0
dataT[dataT[0::,11] =='E',11] = 1
dataT[dataT[0::,11] =='N',11] = 0
dataT[dataT[0::,12] =='E',12] = 1
dataT[dataT[0::,12] =='N',12] = 0
dataT[dataT[0::,13] =='E',13] = 1
dataT[dataT[0::,13] =='N',13] = 0
dataT[dataT[0::,14] =='E',14] = 1
dataT[dataT[0::,14] =='N',14] = 0
dataT[dataT[0::,15] =='E',15] = 1
dataT[dataT[0::,15] =='N',15] = 0
dataT[dataT[0::,16] =='E',16] = 1
dataT[dataT[0::,16] =='N',16] = 0
dataT[dataT[0::,17] =='E',17] = 1
dataT[dataT[0::,17] =='N',17] = 0

#	Energy-like solvent accessibility propensities
#	Burried or Surface
dataT[dataT[0::,18] =='S',18] = 1
dataT[dataT[0::,18] =='B',18] = 0
dataT[dataT[0::,19] =='S',19] = 1
dataT[dataT[0::,19] =='B',19] = 0
dataT[dataT[0::,20] =='S',20] = 1
dataT[dataT[0::,20] =='B',20] = 0
dataT[dataT[0::,21] =='S',21] = 1
dataT[dataT[0::,21] =='B',21] = 0
dataT[dataT[0::,22] =='S',22] = 1
dataT[dataT[0::,22] =='B',22] = 0
dataT[dataT[0::,23] =='S',23] = 1
dataT[dataT[0::,23] =='B',23] = 0
dataT[dataT[0::,24] =='S',24] = 1
dataT[dataT[0::,24] =='B',24] = 0
dataT[dataT[0::,25] =='S',25] = 1
dataT[dataT[0::,25] =='B',25] = 0
dataT[dataT[0::,26] =='S',26] = 1
dataT[dataT[0::,26] =='B',26] = 0

#	Solvent accessibility
dataT[dataT[0::,36] =='E',36] = 1
dataT[dataT[0::,36] =='B',36] = 0
dataT[dataT[0::,37] =='E',37] = 1
dataT[dataT[0::,37] =='B',37] = 0
dataT[dataT[0::,38] =='E',38] = 1
dataT[dataT[0::,38] =='B',38] = 0
dataT[dataT[0::,39] =='E',39] = 1
dataT[dataT[0::,39] =='B',39] = 0
dataT[dataT[0::,40] =='E',40] = 1
dataT[dataT[0::,40] =='B',40] = 0
dataT[dataT[0::,41] =='E',41] = 1
dataT[dataT[0::,41] =='B',41] = 0
dataT[dataT[0::,42] =='E',42] = 1
dataT[dataT[0::,42] =='B',42] = 0
dataT[dataT[0::,43] =='E',43] = 1
dataT[dataT[0::,43] =='B',43] = 0
dataT[dataT[0::,44] =='E',44] = 1
dataT[dataT[0::,44] =='B',44] = 0

#	Secondary structure
dataT[dataT[0::,45] =='H',45] = 0
dataT[dataT[0::,45] =='B',45] = 2
dataT[dataT[0::,45] =='C',45] = 1
dataT[dataT[0::,46] =='H',46] = 0
dataT[dataT[0::,46] =='B',46] = 2
dataT[dataT[0::,46] =='C',46] = 1
dataT[dataT[0::,47] =='H',47] = 0
dataT[dataT[0::,47] =='B',47] = 2
dataT[dataT[0::,47] =='C',47] = 1
dataT[dataT[0::,48] =='H',48] = 0
dataT[dataT[0::,48] =='B',48] = 2
dataT[dataT[0::,48] =='C',48] = 1
dataT[dataT[0::,49] =='H',49] = 0
dataT[dataT[0::,49] =='B',49] = 2
dataT[dataT[0::,49] =='C',49] = 1
dataT[dataT[0::,50] =='H',50] = 0
dataT[dataT[0::,50] =='B',50] = 2
dataT[dataT[0::,50] =='C',50] = 1
dataT[dataT[0::,51] =='H',51] = 0
dataT[dataT[0::,51] =='B',51] = 2
dataT[dataT[0::,51] =='C',51] = 1
dataT[dataT[0::,52] =='H',52] = 0
dataT[dataT[0::,52] =='B',52] = 2
dataT[dataT[0::,52] =='C',52] = 1
dataT[dataT[0::,53] =='H',53] = 0
dataT[dataT[0::,53] =='B',53] = 2
dataT[dataT[0::,53] =='C',53] = 1


X_testData = dataT[:,0:117].astype(float)

#######################################################

model = joblib.load('/your_path/SEPIa/models/model1/model.pkl')

prediction = np.rint(model.predict_proba(X_testData)[:, 1])
     
open_file_object = csv.writer(open("/your_path/SEPIa/prediction/prediction.csv", "w"))
open_file_object.writerow(["Number","Prediction"])
open_file_object.writerows(zip(ids, prediction))

#	Epitope 'E' = 1, Non-epitope 'N' = 0 (State)
