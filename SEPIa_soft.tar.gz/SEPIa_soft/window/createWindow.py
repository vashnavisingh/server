from __future__ import print_function
"""
windows of size 9
"""


#######################################################

import csv as csv
import numpy as np
import sys,os, glob

np.set_printoptions(threshold='nan', precision=3, suppress=True, linewidth = 140)

###### Import data #############
MytestFile = sys.argv[1]
test_file_object = csv.reader(open(MytestFile, "r"))

header = next(test_file_object)
data=[]
for row in test_file_object:
    data.append(row[1:])
data = np.array(data)

ChangeRowCols = data.T

###### sliding window ##########


def sliding_window(sequence, n):
   import numpy as np
   M = []
   for i in range(len(sequence)-2):
      # calculate start and stop
      #window = sequence[i:i+n] #for i in xrange(len(sequence)-2)]
      
      start = max(0,i-n)
      stop = min(len(sequence),i+n) + 1
      window = sequence[start:stop]
      result = []
      for row in window:
      	result.append(row)

      M.append(result)
      
      K = "\n".join(map(str, M))
      
   return K

for i in range(0,13):
	with open('features/featureWtest_{0:02d}.txt'.format(i),'w') as L:
		C = L.write(str(sliding_window(ChangeRowCols[i], 4)))
		
for i in range(0,13):
	with open('features/featureWtest_{0:02d}.csv'.format(i),'w') as L:
		for lines in open('features/featureWtest_{0:02d}.txt'.format(i), "r"):
			C = str(lines).replace('[','').replace(']',',').replace("'", "").replace(" ", "")
			D = L.write(C)

np.savetxt("features/state.txt", data[:,13], fmt="%s", newline='\n')

for i in range(0,13):
	state = open("features/state.txt", "r")
	with open('features/featureWtest_2_{0:02d}.csv'.format(i),'w') as L:
		for lines in open('features/featureWtest_{0:02d}.csv'.format(i), "r"):
   			C = lines.rstrip() + state.readline().strip() + "\n"
   			D = L.write(C)

for i in range(0,13):
	with open('features/featureWtest_3_{0:02d}.csv'.format(i),'w') as L:
		with open('features/featureWtest_2_{0:02d}.csv'.format(i), "r") as lines:
			outtext = ['%d,%s' % (i, line) for i, line in enumerate(lines,1)]
			L.writelines(str("".join(outtext)))

for i in range(0,13):
	from itertools import islice
	with open('features/featureWtest_4_{0:02d}.csv'.format(i),'w') as L:
		with open('features/featureWtest_3_{0:02d}.csv'.format(i), "r") as lines:
   			for line in islice(lines,4,None):
   				L.write(line)

for i in range(0,13):
	with open('features/featureWtest_5_{0:02d}.csv'.format(i),'w') as L:
		with open('features/featureWtest_4_{0:02d}.csv'.format(i), "r") as M:
			lines = M.readlines()
			lines=lines[:-2]
			for line in lines:
				L.write(line)



for i in range(0,13):
	import fileinput
	with open('features/featureW9_{0:02d}.csv'.format(i),'a') as L:
		writer = csv.DictWriter(L, fieldnames = ["Num", "W1", "W2", "W3", "W4", "W5", "W6", "W7", "W8", "W9", "State"], delimiter = ',')
		writer.writeheader()

for i in range(0,13):
	with open('features/featureW9_{0:02d}.csv'.format(i),'a') as L:
		with open('features/featureWtest_5_{0:02d}.csv'.format(i), "r") as lines:
			for rows in lines:
				L.write(rows)

 

for filename in glob.glob('features/featureWtest_*'):
	os.remove(filename)
for filename in glob.glob('features/state.txt'):
	os.remove(filename)						

