Energy-like epitope propensities
- Change the paths
- Use EpitopeProp.py to calculate the energy-like epitope propensities for a new sequence. Insert your sequence inside the EpitopeProp.py file.


Energy-like solvent accessibility propensities
- Change the paths
- Use SolvAccProp.py to calculate the energy-like solvent accessibility propensities for a new sequence. Insert your sequence inside the SolvAccProp_newSeq.py file.

