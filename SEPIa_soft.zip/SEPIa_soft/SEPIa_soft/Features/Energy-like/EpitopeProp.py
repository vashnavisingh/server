#######################################################

def heading():

	"""
	Calculation of Energy-like epitope propensities
	"""
	pass

print (heading.__doc__)
#######################################################


import math as MA
import sys



def EpPred(Sequence):
	TableSE=open("/your_path/SEPIa/Features/Energy-like/EpitopeProp/SinglePotE", "r")
	TableSN=open("/your_path/SEPIa/Features/Energy-like/EpitopeProp/SinglePotN", "r")
	PotE1=eval(TableSE.read())
	PotN1=eval(TableSN.read())
	TableSE.close()
	TableSN.close()
	ValueE1=[]
	ValueN1=[]
	KbT=-0.582250801
	for i in range(len(Sequence)):
		ValueE1.append(0)
		ValueN1.append(0)
		size=0.0
		for j in range(-3,4):
			if i+j>=0:
				try:
					ValueE1[i]+=PotE1[str(j)][Sequence[i+j]]
					ValueN1[i]+=PotN1[str(j)][Sequence[i+j]]
					size+=1.0
				except (IndexError, KeyError):
					pass
		ValueE1[i]=(KbT*ValueE1[i])/size
		ValueN1[i]=(KbT*ValueN1[i])/size
	


	TablePE=open("/your_path/SEPIa/Features/Energy-like/EpitopeProp/PairPotE", "r")
	TablePN=open("/your_path/SEPIa/Features/Energy-like/EpitopeProp/PairPotN", "r")
	PotE2=eval(TablePE.read())
	PotN2=eval(TablePN.read())
	TablePE.close()
	TablePN.close()
	ValueE2=[]
	ValueN2=[]
	KbT=-0.582250801
	for i in range(len(Sequence)):
		ValueE2.append(0)
		ValueN2.append(0)
		size=0.0
		for j in range(-3,4):
			if i+j>=0 and i+j<len(Sequence):
				size+=1.0
		for j in range(-3,3):
			for k in range(j+1,4):
				if i+j>=0 and i+k>=1:
					try:
						ValueE2[i]+=PotE2[str(j)][Sequence[i+j]][str(k)][Sequence[i+k]]
						ValueN2[i]+=PotN2[str(j)][Sequence[i+j]][str(k)][Sequence[i+k]]
					except (IndexError, KeyError):
						pass
		ValueE2[i]=(KbT*ValueE2[i])/size
		ValueN2[i]=(KbT*ValueN2[i])/size

	predict=""
	for i in range(len(ValueE1)):
		if ValueE1[i] + 1.7*ValueE2[i] < ValueN1[i] + 1.7*ValueN2[i]:
			predict+="E"
		elif ValueE1[i] + 1.7*ValueE2[i] > ValueN1[i] + 1.7*ValueN2[i]:
			predict+="N"
		else:
			predict+="X"	
	return predict

#Paste/type the antigen sequence below in single letter amino acid code 
#(e.g. replace the sequence "SEQUENCE" below with your sequence):
Sequence="SEQUENCE"
Energy_like_epitope_propensities=EpPred(Sequence)
print("Sequence:")
print(Sequence)
print("Energy-like epitope propensities:")
print(Energy_like_epitope_propensities)

